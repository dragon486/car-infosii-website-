import Navbar from './components/Navbar';
import Hero from './components/Hero';
import Categories from './components/Categories';
import Events from './components/Events';

function App() {
  return (
    <div className="min-h-screen bg-white">
      <Navbar />
      <Hero />
      <Categories />
      <Events />
      
      <footer className="bg-black text-white py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <p>© 2024 RacingElite. All rights reserved.</p>
        </div>
      </footer>
    </div>
  );
}

export default App;