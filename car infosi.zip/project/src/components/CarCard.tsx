interface CarCardProps {
  name: string;
  category: string;
  image: string;
  specs: {
    power: string;
    acceleration: string;
    topSpeed: string;
  };
}

export default function CarCard({ name, category, image, specs }: CarCardProps) {
  return (
    <div className="bg-white rounded-lg overflow-hidden shadow-lg transform transition-all duration-300 hover:scale-105">
      <div className="relative">
        <img src={image} alt={name} className="w-full h-48 object-cover" />
        <div className="absolute top-0 right-0 bg-red-600 text-white px-3 py-1 rounded-bl-lg">
          {category}
        </div>
      </div>
      
      <div className="p-4">
        <h3 className="text-xl font-bold mb-2">{name}</h3>
        <div className="space-y-2">
          <div className="flex justify-between">
            <span className="text-gray-600">Power</span>
            <span className="font-semibold">{specs.power}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-gray-600">0-60 mph</span>
            <span className="font-semibold">{specs.acceleration}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-gray-600">Top Speed</span>
            <span className="font-semibold">{specs.topSpeed}</span>
          </div>
        </div>
        
        <button className="mt-4 w-full bg-black text-white py-2 rounded-md hover:bg-gray-800 transition-colors">
          View Details
        </button>
      </div>
    </div>
  );
}