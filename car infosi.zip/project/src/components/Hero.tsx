import { ChevronDown } from 'lucide-react';

export default function Hero() {
  return (
    <div className="relative h-screen">
      <video 
        autoPlay 
        loop 
        muted 
        className="absolute inset-0 w-full h-full object-cover"
        style={{ filter: 'brightness(0.6)' }}
      >
        <source src="https://player.vimeo.com/external/504246881.sd.mp4?s=aa43d0bcad7f6c14f13d9be4b4d08fb3f8acb4c1&profile_id=164&oauth2_token_id=57447761" type="video/mp4" />
      </video>
      
      <div className="absolute inset-0 flex flex-col items-center justify-center text-white">
        <h1 className="text-5xl md:text-7xl font-bold text-center mb-6 animate-fade-in">
          Welcome to Racing Elite
        </h1>
        <p className="text-xl md:text-2xl text-center mb-8 max-w-2xl px-4">
          Discover the world's most prestigious racing cars and their legendary stories
        </p>
        <a 
          href="#categories"
          className="bg-red-600 hover:bg-red-700 text-white px-8 py-3 rounded-full 
                   transition-all duration-300 transform hover:scale-105"
        >
          Explore Cars
        </a>
      </div>
      
      <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 animate-bounce">
        <ChevronDown className="w-8 h-8 text-white" />
      </div>
    </div>
  );
}