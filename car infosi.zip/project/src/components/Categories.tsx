import CarCard from './CarCard';

const cars = [
  {
    name: "Ferrari SF90 Stradale",
    category: "Formula 1",
    image: "https://images.unsplash.com/photo-1592198084033-aade902d1aae?auto=format&fit=crop&w=800",
    specs: {
      power: "986 HP",
      acceleration: "2.5s",
      topSpeed: "211 mph"
    }
  },
  {
    name: "Porsche 919 Hybrid",
    category: "Le Mans",
    image: "https://images.unsplash.com/photo-1614200187524-dc4b892acf16?auto=format&fit=crop&w=800",
    specs: {
      power: "900 HP",
      acceleration: "2.2s",
      topSpeed: "230 mph"
    }
  },
  {
    name: "McLaren P1 GTR",
    category: "GT",
    image: "https://images.unsplash.com/photo-1544636331-e26879cd4d9b?auto=format&fit=crop&w=800",
    specs: {
      power: "986 HP",
      acceleration: "2.4s",
      topSpeed: "225 mph"
    }
  }
];

export default function Categories() {
  return (
    <section id="categories" className="py-20 bg-gray-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <h2 className="text-4xl font-bold text-center mb-12">Racing Categories</h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {cars.map((car, index) => (
            <CarCard key={index} {...car} />
          ))}
        </div>
      </div>
    </section>
  );
}